import os
import telebot
import subprocess
import tempfile
import random
import string
from pathlib import Path

# Initialize Telegram Bot
TOKEN = os.environ.get("TELEGRAM_BOT_TOKEN")
if not TOKEN:
    print("TELEGRAM_BOT_TOKEN not found in environment variables")
    exit(1)

bot = telebot.TeleBot(TOKEN)

def get_sticker_set_name(user_id):
    return f"vid_stickers_{user_id}_by_{bot.get_me().username}"

@bot.message_handler(content_types=['video', 'animation', 'document'])
def handle_media(message):
    chat_id = message.chat.id
    user_id = message.from_user.id
    username = message.from_user.username or message.from_user.first_name
    
    # Check for video/gif content
    file_id = None
    if message.video:
        file_id = message.video.file_id
    elif message.animation:
        file_id = message.animation.file_id
    elif message.document and (message.document.mime_type == 'video/mp4' or message.document.mime_type == 'image/gif'):
        file_id = message.document.file_id
        
    if not file_id:
        return

    print(f"Received media from {username}")
    status_msg = bot.send_message(chat_id, "⏳ Downloading and processing media...")
    
    try:
        # Create temp directory
        with tempfile.TemporaryDirectory() as temp_dir:
            file_info = bot.get_file(file_id)
            downloaded_file = bot.download_file(file_info.file_path)
            
            input_path = Path(temp_dir) / "input_media"
            output_path = Path(temp_dir) / "sticker.webm"
            
            with open(input_path, 'wb') as f:
                f.write(downloaded_file)
                
            # Process with ffmpeg
            command = [
                'ffmpeg', '-i', str(input_path),
                '-c:v', 'libvpx-vp9',
                '-pix_fmt', 'yuva420p',
                '-vf', 'scale=512:512:force_original_aspect_ratio=decrease',
                '-t', '3',
                '-an',
                '-y',
                str(output_path)
            ]
            
            subprocess.run(command, check=True, capture_output=True)
            
            # Send sticker to Telegram to get file_id for sticker pack
            with open(output_path, 'rb') as sticker_file:
                sent_sticker = bot.send_sticker(chat_id, sticker_file)
                sticker_file_id = sent_sticker.sticker.file_id

            try:
                # Create or add to sticker set
                set_name = get_sticker_set_name(user_id)
                try:
                    # Try to add to existing set
                    bot.add_sticker_to_set(
                        user_id=user_id,
                        name=set_name,
                        sticker=telebot.types.InputSticker(sticker_file_id, ['✨']),
                        emojis='✨'
                    )
                except Exception as e:
                    error_str = str(e).lower()
                    if "stickerset_invalid" in error_str or "peer_id_invalid" in error_str:
                        # Create new set
                        bot.create_new_sticker_set(
                            user_id=user_id,
                            name=set_name,
                            title=f"{username}'s Video Stickers",
                            stickers=[telebot.types.InputSticker(sticker_file_id, ['✨'])],
                            sticker_format='video'
                        )
                    elif "unexpected keyword argument 'emojis'" in error_str:
                        # Fallback for newer versions that only use InputSticker's emojis
                        bot.add_sticker_to_set(
                            user_id=user_id,
                            name=set_name,
                            sticker=telebot.types.InputSticker(sticker_file_id, ['✨'])
                        )
                    elif "required positional argument: 'emojis'" in error_str:
                        # Fallback for older versions that require emojis as positional arg
                        bot.add_sticker_to_set(
                            user_id,
                            set_name,
                            '✨',
                            sticker=sticker_file_id
                        )
                    else:
                        raise e
                    
                bot.send_message(chat_id, f"✅ Added to your pack: t.me/addstickers/{set_name}")
                bot.delete_message(chat_id, status_msg.message_id)
                print("Added sticker to pack")
            except Exception as e:
                print(f"Sticker pack error: {e}")
                bot.edit_message_text(f"❌ Error adding to pack: {str(e)}", chat_id, status_msg.message_id)

    except Exception as e:
        print(f"Processing error: {e}")
        bot.edit_message_text(f"❌ Error processing media: {str(e)}", chat_id, status_msg.message_id)

@bot.message_handler(func=lambda message: True)
def echo_all(message):
    print(f"Received message from {message.from_user.username or message.from_user.first_name}: {message.text}")
    reply_text = "Send me a video or GIF to create a sticker and add it to your personal pack!"
    bot.reply_to(message, reply_text)

if __name__ == "__main__":
    print("Telegram bot started successfully")
    bot.infinity_polling()
