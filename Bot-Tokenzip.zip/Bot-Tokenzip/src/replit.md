# Bot-Token

## Overview

A Telegram bot dashboard application that monitors and visualizes bot activity in real-time. The system consists of a Telegram bot backend that processes messages (including sticker generation from video/gif content) and a React-based frontend dashboard that displays message logs, statistics, and user interactions.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Framework**: React 18 with TypeScript
- **Build Tool**: Vite with custom configuration
- **Routing**: Wouter (lightweight React router)
- **State Management**: TanStack React Query for server state with 3-second polling for real-time updates
- **UI Components**: shadcn/ui component library built on Radix UI primitives
- **Styling**: Tailwind CSS with custom CSS variables for theming
- **Animations**: Framer Motion for smooth list entry animations

### Backend Architecture
- **Runtime**: Node.js with Express
- **Language**: TypeScript with ESM modules
- **Telegram Integration**: node-telegram-bot-api with polling mode
- **Media Processing**: fluent-ffmpeg with @ffmpeg-installer/ffmpeg for video/gif to sticker conversion
- **API Design**: REST endpoints defined in shared/routes.ts with Zod schema validation

### Data Storage
- **Database**: PostgreSQL with Drizzle ORM
- **Schema Location**: shared/schema.ts
- **Migrations**: Drizzle Kit with migrations output to ./migrations
- **Connection**: pg Pool with DATABASE_URL environment variable

### Project Structure
```
├── client/          # React frontend
│   └── src/
│       ├── components/  # UI components including shadcn/ui
│       ├── hooks/       # Custom React hooks
│       ├── lib/         # Utilities and query client
│       └── pages/       # Route components
├── server/          # Express backend
│   ├── routes.ts    # API routes and Telegram bot logic
│   ├── storage.ts   # Database operations
│   └── db.ts        # Database connection
├── shared/          # Shared types and schemas
│   ├── schema.ts    # Drizzle database schema
│   └── routes.ts    # API route definitions
└── script/          # Build scripts
```

### Key Design Decisions
1. **Monorepo Structure**: Client and server share TypeScript types through the shared/ directory, ensuring type safety across the stack
2. **Polling for Telegram**: Uses polling mode for simplicity instead of webhooks, suitable for development
3. **Real-time Updates**: Frontend polls the API every 3 seconds rather than using WebSockets, balancing simplicity with near-real-time updates
4. **Shared Schema Validation**: Zod schemas in shared/routes.ts validate both API responses and database operations

## External Dependencies

### Database
- **PostgreSQL**: Required database, connection via DATABASE_URL environment variable

### Environment Variables
- `DATABASE_URL`: PostgreSQL connection string (required)
- `TELEGRAM_BOT_TOKEN`: Telegram Bot API token (required for bot functionality)

### Third-Party Services
- **Telegram Bot API**: Core integration for receiving and sending messages
- **FFmpeg**: System dependency for media processing (bundled via @ffmpeg-installer/ffmpeg)

### Key NPM Packages
- `node-telegram-bot-api`: Telegram bot integration
- `drizzle-orm` + `drizzle-kit`: Database ORM and migrations
- `@tanstack/react-query`: Server state management
- `fluent-ffmpeg`: Video/audio processing wrapper
- Full shadcn/ui component set via Radix UI primitives