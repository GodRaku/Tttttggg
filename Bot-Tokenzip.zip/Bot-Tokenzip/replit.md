# Bot-Token

## Overview

A Telegram bot that converts videos and GIFs into Telegram video stickers. The bot receives media files via Telegram, processes them using FFmpeg to meet Telegram's sticker format requirements (VP9 codec, max 512x512 resolution, max 3 seconds duration, transparency support), and returns the converted sticker.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Bot Architecture
- **Language**: Python
- **Telegram Library**: pyTeleBot for handling Telegram Bot API interactions
- **Media Processing**: FFmpeg for video/GIF to WebM sticker conversion
- **Deployment**: Single Python script (`src/bot.py`) running as a long-polling Telegram bot

### Media Processing Pipeline
1. Bot receives video, animation (GIF), or document messages
2. Downloads media to a temporary directory
3. Processes with FFmpeg using VP9 codec (`libvpx-vp9`)
4. Outputs WebM format with:
   - Max 512x512 resolution (Telegram sticker requirement)
   - Max 3 seconds duration
   - YUVA420P pixel format for transparency support
5. Returns processed sticker to user

### Configuration
- **Environment Variables**: `TELEGRAM_BOT_TOKEN` required for bot authentication
- **Temporary Storage**: Uses Python's `tempfile.TemporaryDirectory` for processing (auto-cleanup)

## External Dependencies

### Third-Party Services
- **Telegram Bot API**: Primary interface for receiving and sending messages/media

### System Dependencies
- **FFmpeg**: Required for media transcoding (must be installed on system)

### Python Packages
- **pyTeleBot**: Telegram Bot API wrapper
- Standard library: `os`, `subprocess`, `tempfile`, `pathlib`